//
//  ViewController6.swift
//  KCCM
//
//  Created by 김용호 on 12/08/2019.
//  Copyright © 2019 kcc. All rights reserved.
//
// 회비 화면
import Foundation
import UIKit

class Dues: UIViewController {
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
}
